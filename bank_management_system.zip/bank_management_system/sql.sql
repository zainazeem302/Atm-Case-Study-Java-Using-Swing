create database bank_management_system;

show databases;

use bankmanagementsystem;

create table signupone(formno varchar(20),name varchar(20),father_name varchar(20),dob varchar(20),gender varchar(20),email varchar(50),marital_status varchar(20),address varchar(80),city varchar(20),state varchar(20),pincode varchar(20));

show tables;

select * from signupone;


create table signuptwo(formno varchar(20),religion varchar(20),category varchar(20),income varchar(20),education varchar(20),occupation varchar(20),pan varchar(20),cnic varchar(20),senior_citizen varchar(20),excisting_account varchar(20));

select * from signuptwo;
select * from login;
create table signupthree(formno varchar(100),accounttype varchar(100),cardnumber varchar(100),pin varchar(100),facility varchar(100));
create table login(formno varchar(20),card_number varchar(25),pin varchar(10));
select * from signupthree;
drop table signupthree;
create table bank(pin varchar(10),date varchar(20),type varchar(20),amount varchar(20));
select * from bank;
