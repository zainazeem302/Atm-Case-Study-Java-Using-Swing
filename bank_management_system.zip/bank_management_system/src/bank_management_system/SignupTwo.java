package bank_management_system;


import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

public class SignupTwo extends JFrame implements ActionListener{
    

JTextField cnic1,pan1;
JButton next;
JRadioButton ea,ea2,ysc,nsc;
JComboBox religion1,category,occupation1,education1,income1;
String formno;
JLabel sc,editionaldetails,religion,qualification,category1,income,occupation,pan,cnic;
SignupTwo(String formno){
    this.formno=formno;
        setLayout(null);
        setTitle("NEW ACCOUNT APPLICATION FORM 2");
        
        Random ran=new Random();
       
        editionaldetails=new JLabel("Page 2:Editional Details"); //NAMEOFJFRAME
        editionaldetails.setFont(new Font("Raleway",Font.BOLD,25));
        editionaldetails.setBounds(280,80,400,30);
        add(editionaldetails);
        
         religion=new JLabel("Religion:"); //NAMEOFJFRAME
        religion.setFont(new Font("Raleway",Font.BOLD,15));
        religion.setBounds(100,140,100,30);
        add(religion);
        
        String valReligion[]={"Select","Muslim","Hindu","Cristian","Sikh"};
         religion1=new JComboBox(valReligion);
        religion1.setBounds(300,140,400,30);
        add(religion1);
        
         category1=new JLabel("Category:"); //NAMEOFJFRAME
        category1.setFont(new Font("Raleway",Font.BOLD,15));
        category1.setBounds(100,190,200,30);   
        add(category1);
        
        String valCategory[]={"General","high","low"};
         category=new JComboBox(valCategory); 
        category.setBounds(300,190,400,30);
         add(category);       
        
        
        
         income=new JLabel("Income:"); //NAMEOFJFRAME
        income.setFont(new Font("Raleway",Font.BOLD,15));
        income.setBounds(100,240,200,30);
        add(income);
        String valincome[]={"NULL","<1,50,000","<2,50,000","5,00,000","Upto 100,000"};
        income1=new JComboBox(valincome); 
        income1.setBounds(300,240,400,30);
         add(income1);       
              
        
        JLabel education=new JLabel("Educational"); //NAMEOFJFRAME
        education.setFont(new Font("Raleway",Font.BOLD,15));
        education.setBounds(100,290,200,30);
        add(education);
        
        
        
   
        
         qualification=new JLabel("Qualification:"); //NAMEOFJFRAME
        qualification.setFont(new Font("Raleway",Font.BOLD,15));
        qualification.setBounds(100,340,200,30);
        add(qualification);
        
        String educationvalues[]={"Non graduate","Graduation","Post Graduate","Doctoriate","Other"};
         education1=new JComboBox(educationvalues); 
        education1.setBounds(300,315,400,30);
         add(education1);
         
        
         
        
          occupation=new JLabel("Occupation:"); //NAMEOFJFRAME
        occupation.setFont(new Font("Raleway",Font.BOLD,15));
         occupation.setBounds(100,390,200,30);
        add(occupation);
        
        
        String occupationvalues[]={"Salary","Self employ","Student","Businessman","Other"};
         occupation1=new JComboBox(occupationvalues); 
        occupation1.setBounds(300,390,400,30);
         add(occupation1);
        
         
        
        
        
        pan=new JLabel("PAN Number:"); //NAMEOFJFRAME
        pan.setFont(new Font("Raleway",Font.BOLD,15));
        pan.setBounds(100,440,200,30);
        add(pan);
        
          pan1=new JTextField();
        pan1.setFont(new Font("raleway",Font.BOLD,14));
        pan1.setBounds(300,440,400,30);
        add(pan1);
        
        
        cnic=new JLabel("Cnic Number:"); //NAMEOFJFRAME
        cnic.setFont(new Font("Raleway",Font.BOLD,15));
        cnic.setBounds(100,490,200,30);
        add(cnic);
        
        cnic1=new JTextField();
        cnic1.setFont(new Font("raleway",Font.BOLD,14));
        cnic1.setBounds(300,490,400,30);
        add(cnic1);
        
        sc=new JLabel("Senior Citizen:"); //NAMEOFJFRAME
        sc.setFont(new Font("Raleway",Font.BOLD,15));
        sc.setBounds(100,540,200,30);
        add(sc);
        
        
         ysc=new JRadioButton("YES");
         ysc.setBounds(350,550,200,30);
        ysc.setBackground(Color.WHITE);
        add(ysc);
        
         nsc=new JRadioButton("NO");
        nsc.setBounds(550,550,100,30);
        nsc.setBackground(Color.WHITE);
        add(nsc);
        
        ButtonGroup syes=new ButtonGroup();
        syes.add(ysc);
        syes.add(nsc);
        
        JLabel pincode=new JLabel("Existing Account:"); //NAMEOFJFRAME
        pincode.setFont(new Font("Raleway",Font.BOLD,15));
        pincode.setBounds(100,590,150,30);
        add(pincode);
        
         ea=new JRadioButton("YES");
       ea.setBounds(350,590,100,30);
        ea.setBackground(Color.WHITE);
        add(ea);
        
        ea2=new JRadioButton("NO");
       ea2.setBounds(550,590,100,30);
        ea2.setBackground(Color.WHITE);
        add(ea2);
        
        ButtonGroup ea1=new ButtonGroup();
        ea1.add(ea);
        ea1.add(ea2);
        
        
       next=new JButton("NEXT");
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.setBounds(720,720,90,30);
        next.addActionListener(this);
        add(next);
                
        getContentPane().setBackground(Color.WHITE);//forbackgroundcolorofframe
        setSize(850,800);   //todisplayofJFrame
        setLocation(350,10);
        setVisible(true);   //bydefaultsetvesiblefunctionisfalse
    }
public void actionPerformed(ActionEvent ae ){

    String religion=(String)religion1.getSelectedItem();
    String scategory=(String)category.getSelectedItem();
    String sincome=(String)income1.getSelectedItem();
      String seducation=(String)education1.getSelectedItem();
        String soccupation=(String)occupation1.getSelectedItem();
        String seniorcitizen=null;
        String existingaccount=null;
    
    if(ysc.isSelected()){
        seniorcitizen="Yes";
    }else if(nsc.isSelected()){
        seniorcitizen="No";
    }
    if(ea.isSelected()){
       existingaccount="Yes";
    }else if(ea2.isSelected()){
        existingaccount="No";
    }
    String span=pan1.getText();
    String scnic=cnic1.getText();
    
   
    
    try{
        if(cnic1.equals("")){
        JOptionPane.showMessageDialog(null,"name is required");
        
        }else{
            Conn c=new Conn();
            String query="Insert into signuptwo values('"+formno+"','"+religion+"','"+scategory+"','"+sincome+"','"+seducation+"','"+soccupation+"','"+span+"','"+scnic+"','"+seniorcitizen+"','"+existingaccount+"')";
            c.s.executeUpdate(query);
            
            setVisible(false);
            new SignupThree(formno).setVisible(true);
        }
    }catch(Exception e){
        System.out.println(e);
    }
}
   
    public static void main(String[] args) {
       new SignupTwo("");
        
    }
    
}


