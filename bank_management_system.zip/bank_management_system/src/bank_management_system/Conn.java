package bank_management_system;

//mysql is an external entity so the error will may be come in run time
import java.sql.*;

public class Conn{
    Connection c;
    Statement s;
    public Conn(){
        //varchat is used for length of text and it is a datatype
        try{
            c=DriverManager.getConnection("jdbc:mysql:///bankmanagementsystem","root","Perdixperdix@12");   //username=root and password=Perdixperdix@12
        s=c.createStatement();
        
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
      
    }
        
    


