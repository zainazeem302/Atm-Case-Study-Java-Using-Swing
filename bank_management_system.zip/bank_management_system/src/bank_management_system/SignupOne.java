package bank_management_system;


import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

public class SignupOne extends JFrame implements ActionListener{
    
long random; //randoom has a form number
JTextField nameTextField,fnameTextField,dobTextField,emailTextField,addressTextField,cityTextField,stateTextField,pinTextField;
JButton next;
JRadioButton male,female,other,married,unmarried;
JDateChooser dateChooser;
JLabel maritalstatus;
SignupOne(){
        setLayout(null);
        
        Random ran=new Random();
        random=Math.abs((ran.nextLong()%9000L)+1000L); //math.absolute is used to eliminate the negative number 
        
        JLabel formno=new JLabel("APPLICATION FORM NUMBER."+random); //NAMEOFJFRAME
        formno.setFont(new Font("Raleway",Font.BOLD,33));
        formno.setBounds(140,20,600,40);
        add(formno);
        
        JLabel personaldetails=new JLabel("Page 1:Personal Details"); //NAMEOFJFRAME
        personaldetails.setFont(new Font("Raleway",Font.BOLD,28));
        personaldetails.setBounds(280,80,400,30);
        add(personaldetails);
        
        JLabel name=new JLabel("Name:"); //NAMEOFJFRAME
        name.setFont(new Font("Raleway",Font.BOLD,22));
        name.setBounds(100,140,120,30);
        add(name);
        
        nameTextField=new JTextField();
        nameTextField.setFont(new Font("raleway",Font.BOLD,14));
        nameTextField.setBounds(300,140,400,30);
        add(nameTextField);
        
        
       
        
        JLabel fname=new JLabel("Father Name:"); //NAMEOFJFRAME
        fname.setFont(new Font("Raleway",Font.BOLD,22));
        fname.setBounds(100,190,200,30);
        add(fname);
        
          fnameTextField=new JTextField();
        fnameTextField.setFont(new Font("raleway",Font.BOLD,14));
        fnameTextField.setBounds(300,190,400,30);
        add(fnameTextField);
        
        JLabel dob=new JLabel("Date of Birth:"); //NAMEOFJFRAME
        dob.setFont(new Font("Raleway",Font.BOLD,22));
        dob.setBounds(100,240,200,30);
        add(dob);
        
        dateChooser=new JDateChooser();
        dateChooser.setBounds(400,240,300,30);
        dateChooser.setForeground(Color.BLACK);
        add(dateChooser);        
        
        JLabel gender=new JLabel("Gender:"); //NAMEOFJFRAME
        gender.setFont(new Font("Raleway",Font.BOLD,22));
        gender.setBounds(100,290,200,30);
        add(gender);
        
         male=new JRadioButton("Male");
        male.setBackground(Color.WHITE);
        male.setBounds(300,290,60,30);
        add(male);
        
         female=new JRadioButton("Female");
        male.setBackground(Color.WHITE);
        female.setBounds(450,290,120,30);
        add(female);
        
        ButtonGroup buttongroup=new ButtonGroup();
        buttongroup.add(male);
        buttongroup.add(female);
        
        
        JLabel email=new JLabel("Gmail Address:"); //NAMEOFJFRAME
        email.setFont(new Font("Raleway",Font.BOLD,22));
        email.setBounds(100,340,200,30);
        add(email);
        
        
        
        emailTextField=new JTextField();
        emailTextField.setFont(new Font("raleway",Font.BOLD,14));
        emailTextField.setBounds(300,340,400,30);
        add(emailTextField);
        
         maritalstatus=new JLabel("Marital Status:"); //NAMEOFJFRAME
        maritalstatus.setFont(new Font("Raleway",Font.BOLD,22));
         maritalstatus.setBounds(100,390,200,30);
        add( maritalstatus);
        
        married=new JRadioButton("married");
        married.setBackground(Color.WHITE);
        married.setBounds(300,390,100,30);
        add(married);
        
        unmarried=new JRadioButton("unmarried");
        unmarried.setBackground(Color.WHITE);
        unmarried.setBounds(450,390,100,30);
        add(unmarried);
        
        other=new JRadioButton("OTHER");
        other.setBackground(Color.WHITE);
        other.setBounds(630,390,100,30);
        
        ButtonGroup buttongroup1=new ButtonGroup();
        buttongroup1.add(married);
        buttongroup1.add(unmarried);
        buttongroup1.add(other);
       
        
        JLabel address=new JLabel("Address:"); //NAMEOFJFRAME
        address.setFont(new Font("Raleway",Font.BOLD,22));
        address.setBounds(100,440,200,30);
        add(address);
        
        addressTextField=new JTextField();
        addressTextField.setFont(new Font("raleway",Font.BOLD,14));
        addressTextField.setBounds(300,440,400,30);
        add(addressTextField);
        
        
        JLabel city=new JLabel("City:"); //NAMEOFJFRAME
        city.setFont(new Font("Raleway",Font.BOLD,22));
        city.setBounds(100,490,200,30);
        add(city);
        
        cityTextField=new JTextField();
        cityTextField.setFont(new Font("raleway",Font.BOLD,14));
        cityTextField.setBounds(300,490,400,30);
        add(cityTextField);
        
        JLabel state=new JLabel("State:"); //NAMEOFJFRAME
        state.setFont(new Font("Raleway",Font.BOLD,22));
        state.setBounds(100,540,200,30);
        add(state);
        
        stateTextField=new JTextField();
        stateTextField.setFont(new Font("raleway",Font.BOLD,14));
        stateTextField.setBounds(300,540,400,30);
        add(stateTextField);
        
        JLabel pincode=new JLabel("Pin Code:"); //NAMEOFJFRAME
        pincode.setFont(new Font("Raleway",Font.BOLD,22));
        pincode.setBounds(100,590,200,30);
        add(pincode);
        
         pinTextField=new JTextField();
        pinTextField.setFont(new Font("raleway",Font.BOLD,14));
        pinTextField.setBounds(300,590,400,30);
        add(pinTextField);
        
        JButton next=new JButton("NEXT");
        next.setBackground(Color.BLACK);
        next.setForeground(Color.WHITE);
        next.setBounds(620,620,90,30);
        next.addActionListener(this);
        add(next);
                
        getContentPane().setBackground(Color.WHITE);//forbackgroundcolorofframe
        setSize(850,800);   //todisplayofJFrame
        setLocation(350,10);
        setVisible(true);   //bydefaultsetvesiblefunctionisfalse
    }
public void actionPerformed(ActionEvent ae ){
    String formno= "" + random;//long value 
    String name=nameTextField.getText();
    String fname=fnameTextField.getText();
    String dob=((JTextField)dateChooser.getDateEditor().getUiComponent()).getText();
    String gender=null;
    if(male.isSelected()){
        gender="Male";
    }else if(female.isSelected()){
        gender="female";
    }
    String email=emailTextField.getText();
    String maritalstatus=null;
    if(married.isSelected()){
        maritalstatus="Married";
    }else if(unmarried.isSelected()){
        maritalstatus="unmarried";
    }else if(other.isSelected()){
        maritalstatus="other";
    }
    String address=addressTextField.getText();
    String city=cityTextField.getText();
    String state=stateTextField.getText();
    String pin=pinTextField.getText();
    try{
        if(name.equals("")){
        JOptionPane.showMessageDialog(null,"name is required");
        
        }else{
            Conn c=new Conn();
            String query="Insert into signup values('"+formno+"','"+name+"','"+fname+"','"+dob+"','"+gender+"','"+email+"','"+maritalstatus+"','"+address+"','"+city+"','"+state+"','"+pin+"')";
            c.s.executeUpdate(query);
            
            setVisible(false);
            new SignupTwo(formno).setVisible(true);
        }
    }catch(Exception e){
        System.out.println(e);
    }
}
   
    public static void main(String[] args) {
       new SignupOne();
        
    }
    
}

